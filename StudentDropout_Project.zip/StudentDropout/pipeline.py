"""
Student Dropout Risk Predictor — ML Pipeline
Generates all model artifacts, plots, and metrics needed for the notebook and report.
"""

import os, warnings, json, pickle
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns

from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, roc_curve, f1_score,
    accuracy_score, precision_score, recall_score
)
from sklearn.impute import SimpleImputer
from imblearn.over_sampling import SMOTE

os.makedirs("/home/claude/artifacts", exist_ok=True)
os.makedirs("/home/claude/plots", exist_ok=True)

# ─────────────────────────────────────────────
# 1. SYNTHETIC DATA (mirrors UCI dropout dataset)
# ─────────────────────────────────────────────
np.random.seed(42)
N = 4424

def make_dataset(n):
    dropout_mask = np.random.rand(n) < 0.32   # ~32% dropout rate (close to UCI)

    age          = np.where(dropout_mask, np.random.normal(23, 4, n), np.random.normal(20, 3, n)).clip(17, 60).astype(int)
    prev_grade   = np.where(dropout_mask, np.random.normal(110, 20, n), np.random.normal(130, 18, n)).clip(60, 200)
    adm_grade    = np.where(dropout_mask, np.random.normal(115, 22, n), np.random.normal(135, 20, n)).clip(60, 200)
    units_enr    = np.where(dropout_mask, np.random.normal(4, 2, n), np.random.normal(6, 1.5, n)).clip(0, 12).astype(int)
    units_appr   = np.where(dropout_mask, np.random.normal(2, 2, n), np.random.normal(5, 1.5, n)).clip(0, 12).astype(int)
    units_grade  = np.where(dropout_mask, np.random.normal(8, 4, n), np.random.normal(13, 3, n)).clip(0, 20)
    debtor       = np.where(dropout_mask, np.random.binomial(1, 0.35, n), np.random.binomial(1, 0.08, n))
    tuition_ok   = np.where(dropout_mask, np.random.binomial(1, 0.55, n), np.random.binomial(1, 0.92, n))
    scholarship  = np.where(dropout_mask, np.random.binomial(1, 0.18, n), np.random.binomial(1, 0.30, n))
    gender       = np.random.binomial(1, 0.45, n)   # 1=Male
    marital      = np.random.choice([1,2,3,4,5,6], size=n, p=[0.6,0.2,0.1,0.05,0.03,0.02])
    nationality  = np.random.choice(list(range(1,22)), size=n)
    prev_qual    = np.random.choice([1,2,3,4,5,6], size=n, p=[0.5,0.2,0.1,0.1,0.05,0.05])

    target = np.where(dropout_mask, "Dropout", "Graduate")

    df = pd.DataFrame({
        "Age_at_enrollment":       age,
        "Previous_qualification_grade": prev_grade,
        "Admission_grade":         adm_grade,
        "Curricular_units_enrolled": units_enr,
        "Curricular_units_approved": units_appr,
        "Curricular_units_grade":  units_grade,
        "Debtor":                  debtor,
        "Tuition_fees_up_to_date": tuition_ok,
        "Scholarship_holder":      scholarship,
        "Gender":                  gender,
        "Marital_status":          marital,
        "Nationality":             nationality,
        "Previous_qualification":  prev_qual,
        "Target":                  target,
    })
    return df

df = make_dataset(N)
df.to_csv("/home/claude/artifacts/student_data.csv", index=False)
print(f"Dataset: {df.shape}  |  Dropout rate: {(df.Target=='Dropout').mean():.2%}")

# ─────────────────────────────────────────────
# 2. EDA PLOTS
# ─────────────────────────────────────────────
palette = {"Dropout": "#e74c3c", "Graduate": "#2ecc71"}

# 2a. Class distribution
fig, ax = plt.subplots(figsize=(6, 4))
counts = df["Target"].value_counts()
bars = ax.bar(counts.index, counts.values, color=[palette[k] for k in counts.index], width=0.5, edgecolor="white")
for bar, val in zip(bars, counts.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 30, str(val), ha='center', fontsize=11, fontweight='bold')
ax.set_title("Class Distribution", fontsize=14, fontweight='bold')
ax.set_ylabel("Count")
ax.set_xlabel("Target Class")
sns.despine()
plt.tight_layout()
plt.savefig("/home/claude/plots/class_distribution.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved class_distribution.png")

# 2b. Correlation heatmap (numeric only)
num_cols = ["Age_at_enrollment","Previous_qualification_grade","Admission_grade",
            "Curricular_units_enrolled","Curricular_units_approved","Curricular_units_grade",
            "Debtor","Tuition_fees_up_to_date","Scholarship_holder"]
corr = df[num_cols].corr()
fig, ax = plt.subplots(figsize=(9, 7))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0,
            linewidths=0.5, ax=ax, annot_kws={"size": 8})
ax.set_title("Feature Correlation Heatmap", fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig("/home/claude/plots/correlation_heatmap.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved correlation_heatmap.png")

# 2c. Boxplots for top features
top_feats = ["Curricular_units_approved","Admission_grade","Previous_qualification_grade","Curricular_units_grade"]
fig, axes = plt.subplots(1, 4, figsize=(16, 5))
for ax, feat in zip(axes, top_feats):
    groups = [df.loc[df.Target==cls, feat].values for cls in ["Dropout","Graduate"]]
    bp = ax.boxplot(groups, patch_artist=True, widths=0.5,
                    medianprops=dict(color="black", linewidth=2))
    for patch, color in zip(bp['boxes'], ["#e74c3c","#2ecc71"]):
        patch.set_facecolor(color)
        patch.set_alpha(0.8)
    ax.set_xticklabels(["Dropout","Graduate"], fontsize=10)
    ax.set_title(feat.replace("_"," "), fontsize=10, fontweight='bold')
    sns.despine(ax=ax)
plt.suptitle("Key Feature Distributions by Class", fontsize=13, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig("/home/claude/plots/boxplots.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved boxplots.png")

# ─────────────────────────────────────────────
# 3. PREPROCESSING
# ─────────────────────────────────────────────
X = df.drop("Target", axis=1)
y = (df["Target"] == "Dropout").astype(int)

imputer = SimpleImputer(strategy="median")
X_imp = imputer.fit_transform(X)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_imp)

sm = SMOTE(random_state=42)
X_res, y_res = sm.fit_resample(X_scaled, y)
print(f"After SMOTE: {X_res.shape}  |  Dropout: {y_res.sum()}  Graduate: {(y_res==0).sum()}")

# ─────────────────────────────────────────────
# 4. MODEL TRAINING — 5-fold CV
# ─────────────────────────────────────────────
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42),
    "Decision Tree":       DecisionTreeClassifier(max_depth=8, class_weight="balanced", random_state=42),
    "Random Forest":       RandomForestClassifier(n_estimators=150, max_depth=10, class_weight="balanced", random_state=42),
}

cv_results = {}
for name, model in models.items():
    scores = cross_val_score(model, X_res, y_res, cv=skf, scoring="roc_auc")
    cv_results[name] = {"mean_auc": scores.mean(), "std_auc": scores.std(), "scores": scores.tolist()}
    print(f"{name:22s}  AUC: {scores.mean():.4f} ± {scores.std():.4f}")

# ─────────────────────────────────────────────
# 5. FINAL FIT & EVALUATION (80/20 split)
# ─────────────────────────────────────────────
from sklearn.model_selection import train_test_split
X_tr, X_te, y_tr, y_te = train_test_split(X_res, y_res, test_size=0.2, random_state=42, stratify=y_res)

eval_metrics = {}
trained_models = {}
for name, model in models.items():
    model.fit(X_tr, y_tr)
    trained_models[name] = model
    y_pred = model.predict(X_te)
    y_prob = model.predict_proba(X_te)[:,1]
    eval_metrics[name] = {
        "accuracy":  accuracy_score(y_te, y_pred),
        "precision": precision_score(y_te, y_pred),
        "recall":    recall_score(y_te, y_pred),
        "f1":        f1_score(y_te, y_pred),
        "auc_roc":   roc_auc_score(y_te, y_prob),
    }
    print(f"{name:22s}  F1={eval_metrics[name]['f1']:.4f}  AUC={eval_metrics[name]['auc_roc']:.4f}")

# 5a. Confusion matrices
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
for ax, (name, model) in zip(axes, trained_models.items()):
    y_pred = model.predict(X_te)
    cm = confusion_matrix(y_te, y_pred)
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                xticklabels=["Graduate","Dropout"], yticklabels=["Graduate","Dropout"],
                cbar=False, linewidths=0.5)
    ax.set_title(name, fontsize=11, fontweight='bold')
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
plt.suptitle("Confusion Matrices", fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig("/home/claude/plots/confusion_matrices.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved confusion_matrices.png")

# 5b. ROC curves
fig, ax = plt.subplots(figsize=(7, 5))
colors = ["#3498db","#e67e22","#2ecc71"]
for (name, model), color in zip(trained_models.items(), colors):
    y_prob = model.predict_proba(X_te)[:,1]
    fpr, tpr, _ = roc_curve(y_te, y_prob)
    auc = eval_metrics[name]["auc_roc"]
    ax.plot(fpr, tpr, color=color, lw=2, label=f"{name} (AUC={auc:.3f})")
ax.plot([0,1],[0,1],"k--", lw=1)
ax.set_xlabel("False Positive Rate")
ax.set_ylabel("True Positive Rate")
ax.set_title("ROC Curves — All Models", fontsize=13, fontweight='bold')
ax.legend(loc="lower right")
sns.despine()
plt.tight_layout()
plt.savefig("/home/claude/plots/roc_curves.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved roc_curves.png")

# 5c. Feature importances (Random Forest)
rf = trained_models["Random Forest"]
importances = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=True)
fig, ax = plt.subplots(figsize=(8, 6))
colors_fi = ["#e74c3c" if i >= len(importances)-5 else "#95a5a6" for i in range(len(importances))]
ax.barh(importances.index, importances.values, color=colors_fi, edgecolor="white")
ax.set_title("Random Forest — Feature Importances", fontsize=13, fontweight='bold')
ax.set_xlabel("Importance Score")
sns.despine()
plt.tight_layout()
plt.savefig("/home/claude/plots/feature_importances.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved feature_importances.png")

# 5d. CV comparison bar chart
fig, ax = plt.subplots(figsize=(7, 4))
names = list(cv_results.keys())
means = [cv_results[n]["mean_auc"] for n in names]
stds  = [cv_results[n]["std_auc"]  for n in names]
bars  = ax.bar(names, means, yerr=stds, capsize=5, color=["#3498db","#e67e22","#2ecc71"],
               edgecolor="white", width=0.5)
for bar, val in zip(bars, means):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.005, f"{val:.3f}",
            ha='center', fontsize=10, fontweight='bold')
ax.set_ylim(0.7, 1.0)
ax.set_ylabel("Mean AUC-ROC (5-fold CV)")
ax.set_title("Cross-Validation AUC Comparison", fontsize=13, fontweight='bold')
sns.despine()
plt.tight_layout()
plt.savefig("/home/claude/plots/cv_comparison.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved cv_comparison.png")

# ─────────────────────────────────────────────
# 6. SAVE ARTIFACTS FOR APP & REPORT
# ─────────────────────────────────────────────
with open("/home/claude/artifacts/rf_model.pkl","wb") as f:
    pickle.dump(rf, f)
with open("/home/claude/artifacts/scaler.pkl","wb") as f:
    pickle.dump(scaler, f)
with open("/home/claude/artifacts/imputer.pkl","wb") as f:
    pickle.dump(imputer, f)
with open("/home/claude/artifacts/feature_names.json","w") as f:
    json.dump(list(X.columns), f)

top5 = importances.tail(5).index.tolist()[::-1]
with open("/home/claude/artifacts/top_features.json","w") as f:
    json.dump(top5, f)

metrics_out = {
    "cv_results": cv_results,
    "eval_metrics": eval_metrics,
}
with open("/home/claude/artifacts/metrics.json","w") as f:
    json.dump(metrics_out, f, indent=2)

print("\n=== All artifacts saved ===")
print("Top-5 risk features:", top5)
for name, m in eval_metrics.items():
    print(f"  {name}: Acc={m['accuracy']:.3f} P={m['precision']:.3f} R={m['recall']:.3f} F1={m['f1']:.3f} AUC={m['auc_roc']:.3f}")
